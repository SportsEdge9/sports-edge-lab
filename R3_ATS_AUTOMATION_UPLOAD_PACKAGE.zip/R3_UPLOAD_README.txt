SPORTS EDGE LAB — R3 AUTOMATION — ONE-TIME GITHUB SETUP

This package is ready for upload but IS NOT YET DEPLOYED. GitHub's connected
ChatGPT integration returned HTTP 403 on file writes. No remote changes were made.

The following paths must be created in the ROOT of the existing repository:

  .github/workflows/r3-ats-pregame.yml
  scripts/r3_odds_sync.py
  scripts/test_r3_odds_sync.py
  data/r3_model_frozen_v01.json
  R3_ATS_OPERATING_BASELINE.html  (replace previous version)

DO NOT upload the ZIP unchanged: GitHub Pages will not execute or extract it.
Unzip locally, then copy the FILES AND FOLDERS shown above to the repository.
On a Chromebook, https://github.dev/SportsEdge9/sports-edge-lab opens the
web-based editor; you can drag the extracted folders/files into the repo's
file explorer, then Source Control > Commit & Push to MAIN. Hidden `.github`
folder may require Show hidden files (Ctrl+H) in the local file manager.

Your current frozen browser selection remains in localStorage, keyed at
`sports_edge_r3_ops_frozen_v01`; the updated HTML intentionally leaves the
original manual calculator untouched.

After upload:
  1. Open https://github.com/SportsEdge9/sports-edge-lab/actions
  2. Select "R3 ATS Pregame Capture" workflow.
  3. Click "Run workflow" > main > Run workflow.
  4. Confirm the workflow is green. It writes data/r3_auto_picks.json.
  5. Open the existing R3 page and click "Refresh saved picks".

Requirements:
  - Repository Actions secret named ODDSPAPI_API_KEY (never embedded in HTML).
  - GitHub Actions setting Workflow permissions: "Read and write permissions"
    so the workflow can commit the frozen derived picks.
  - Free OddsPapi quota available; script attempts to reserve 40 requests for
    other Sports Edge Lab engines (when account usage information is accessible).

Schedule: Thu 18:15 UTC, Sat 14:15 UTC, Sun 15:15 UTC, Mon 19:15 UTC.
Only games within 36 hours of kickoff can be frozen. Once frozen, picks are
immutable in the published history file. No retroactive rewriting or data
fabrication. Not a verified winning ATS model; model is R3 reconstruction v0.1.
The first run's real API payload has NOT been tested from ChatGPT, because the
API key stays private in GitHub secrets.

IMPORTANT: This is standalone to the R3 research page. No changes to your
existing Moneyline/Totals engines, pregame pages, or live NFL game center.
