"""Offline tests; no API usage, no account secret."""
import json, pathlib, tempfile, unittest
import r3_odds_sync as s

class TestR3(unittest.TestCase):
    def sample_market(self, handicap=-4.5):
        return [{'sportId':14,'marketId':14268,'marketName':'Handicap (incl. overtime)',
            'handicap':handicap,'period':'fulltime',
            'outcomes':[{'outcomeId':14268,'outcomeName':'1'},{'outcomeId':14269,'outcomeName':'2'}]}]
    def leg(self,price,active=True,changed='2026-11-16T12:00:00Z'):
        return {'players':{'0':{'active':active,'price':1+100/abs(price) if price<0 else 1+price/100,
           'priceAmerican':str(price),'changedAt':changed}}}
    def board(self,spread=-4.5,homeprice=-110,awayprice=-110):
        return {'fanduel':{'bookmakerIsActive':True,'suspended':False,'markets':{'14268':{
           'marketActive':True,'outcomes':{'14268':self.leg(homeprice),'14269':self.leg(awayprice)}}}}}

    def test_correct_home_away_prices(self):
        c=s.market_catalog(self.sample_market())
        r=s.choose_quote(self.board(),c)
        self.assertEqual((r['homeSpread'],r['homePrice'],r['awayPrice'],r['book']),(-4.5,-110,-110,'fanduel'))

    def test_no_one_sided_market_or_moneyline_masquerade(self):
        c=s.market_catalog(self.sample_market())
        b=self.board();b['fanduel']['markets']['14268']['outcomes']['14269']=self.leg(-110,False)
        self.assertIsNone(s.choose_quote(b,c))
        self.assertEqual(s.market_catalog([dict(self.sample_market()[0], marketName='Winner (incl. overtime)')]),{})

    def test_r3_chargers_replay_and_push(self):
        model=json.loads(s.MODEL.read_text())
        p=s.predict('LAC','BAL',-4.5,-110,-110,model)
        self.assertEqual((p['side'],p['pickTeam'],p['pickSpread']),('AWAY','LAC',4.5))
        self.assertAlmostEqual(p['projectedHomeMargin'],2.928,3)
        self.assertAlmostEqual(p['coverProbabilityConditional'],.546347,4)
        self.assertAlmostEqual(p['estimatedEVPerUnit'],.043025,4)
        q=s.predict('LAC','BAL',-4.,-110,-110,model)
        self.assertGreater(q['pushProbability'],0)

    def test_unknown_team_not_guessed(self):
        self.assertIsNone(s.pick_team('Blah Team','ZZZ'))
        self.assertEqual(s.pick_team('Los Angeles Rams','LAR'),'LA')

    def test_prior_frozen_never_replaced(self):
        # A simple merge regression: freeze archive keyed by fixture id, even if a new line is supplied.
        with tempfile.TemporaryDirectory() as d:
            path=pathlib.Path(d)/'data.json';prior={'fixtureId':'id1','homeSpread':-4.5,'modelOutput':{'pickTeam':'LAC'}}
            path.write_text(json.dumps({'frozen':[prior]}))
            previous={x['fixtureId']:x for x in json.loads(path.read_text())['frozen']}
            if 'id1' not in previous: previous['id1']={'homeSpread':-5.5}
            self.assertEqual(previous['id1']['homeSpread'],-4.5)

if __name__=='__main__':unittest.main()
