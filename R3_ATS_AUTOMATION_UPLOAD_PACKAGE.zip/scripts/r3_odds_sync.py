#!/usr/bin/env python3
"""Sports Edge Lab R3 reconstruction: OddsPapi NFL spread -> frozen derived picks.

Outputs one *derived pick* per fixture, not sportsbook market dumps. 2026 Week 10
coefficients remain frozen until explicitly versioned. Stdlib only; meant for
GitHub Actions with ODDSPAPI_API_KEY in its Secrets.
"""
import datetime as dt
import json
import math
import os
import pathlib
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from collections import Counter

ROOT = pathlib.Path(__file__).resolve().parents[1]
OUT = ROOT / 'data' / 'r3_auto_picks.json'
MODEL = ROOT / 'data' / 'r3_model_frozen_v01.json'
BASE = 'https://api.oddspapi.io/v4/'
NFL_TOURNAMENT = 31
NFL_SPORT = 14
BOOKS = ('fanduel', 'draftkings', 'pinnacle')
MAX_FIXTURES = 16
CAPTURE_HORIZON_HOURS = 36  # Freeze close to kickoff, not days early.
MIN_QUOTA_RESERVE = 40  # Leave room for the user's other OddsPapi engines.

TEAMS = {
 'Arizona Cardinals':'ARI','Atlanta Falcons':'ATL','Baltimore Ravens':'BAL',
 'Buffalo Bills':'BUF','Carolina Panthers':'CAR','Chicago Bears':'CHI',
 'Cincinnati Bengals':'CIN','Cleveland Browns':'CLE','Dallas Cowboys':'DAL',
 'Denver Broncos':'DEN','Detroit Lions':'DET','Green Bay Packers':'GB',
 'Houston Texans':'HOU','Indianapolis Colts':'IND','Jacksonville Jaguars':'JAX',
 'Kansas City Chiefs':'KC','Los Angeles Rams':'LA','Los Angeles Chargers':'LAC',
 'Las Vegas Raiders':'LV','Miami Dolphins':'MIA','Minnesota Vikings':'MIN',
 'New England Patriots':'NE','New Orleans Saints':'NO','New York Giants':'NYG',
 'New York Jets':'NYJ','Philadelphia Eagles':'PHI','Pittsburgh Steelers':'PIT',
 'Seattle Seahawks':'SEA','San Francisco 49ers':'SF','Tampa Bay Buccaneers':'TB',
 'Tennessee Titans':'TEN','Washington Commanders':'WAS',
}
TEAM_ABBR = {'LAR':'LA','LA':'LA','WSH':'WAS','JAC':'JAX','LV':'LV'}

def utcnow(): return dt.datetime.now(dt.timezone.utc)
def z(t): return t.astimezone(dt.timezone.utc).isoformat(timespec='seconds').replace('+00:00','Z')
def parse_dt(value):
    try: return dt.datetime.fromisoformat(str(value).replace('Z','+00:00')).astimezone(dt.timezone.utc)
    except (ValueError,TypeError,AttributeError): return None

def api_get(path, **params):
    key = os.getenv('ODDSPAPI_API_KEY', '').strip()
    if not key: raise RuntimeError('Missing ODDSPAPI_API_KEY GitHub Actions secret (key is never printed).')
    query=urllib.parse.urlencode(dict(params,apiKey=key))
    req=urllib.request.Request(BASE+path+'?'+query,headers={'Accept':'application/json','User-Agent':'SportsEdgeLab-R3-Audit/1.0'})
    for i in range(3):
        try:
            with urllib.request.urlopen(req,timeout=50) as resp: return json.loads(resp.read())
        except urllib.error.HTTPError as exc:
            if exc.code==404 and path=='fixtures': return []
            if exc.code!=429 or i==2: raise RuntimeError(f'OddsPapi {path} returned HTTP {exc.code}') from None
            # requests per endpoint have cooldown, honor 429 while avoiding secret in errors
            time.sleep(3*(i+1))
        except urllib.error.URLError:
            if i==2: raise RuntimeError(f'Could not connect to OddsPapi {path}') from None
            time.sleep(2*(i+1))
    return None

def records(body):
    if isinstance(body,list): return body
    if isinstance(body,dict):
        for k in ('fixtures','events','data','results','markets'):
            if isinstance(body.get(k),list): return body[k]
    return []

def market_catalog(body):
    result={}
    for m in records(body):
        if m.get('marketName')!='Handicap (incl. overtime)': continue
        if m.get('sportId') not in (NFL_SPORT, str(NFL_SPORT)): continue
        if str(m.get('period','')).lower() not in ('fulltime','full-time','', 'match'): continue
        try:
            mid=str(int(m['marketId']));h=float(m['handicap'])
        except (KeyError,ValueError,TypeError): continue
        if not math.isfinite(h) or round(h*2)!=h*2: continue
        # For NFL full-game handicap markets, catalogue's first outcome is home
        # participant 1. We require two distinct outcomes and reject ambiguity.
        outcomes=m.get('outcomes') or []
        if not isinstance(outcomes,list) or len(outcomes)!=2: continue
        try:
            home_out=str(int(outcomes[0]['outcomeId']))
            away_out=str(int(outcomes[1]['outcomeId']))
        except (ValueError,KeyError,TypeError): continue
        names=[str(x.get('outcomeName','')).strip().lower() for x in outcomes]
        if home_out==away_out: continue
        if names and names[0] in ('2','away','visitor','team 2'):
            continue
        if names and names[1] in ('1','home','team 1'):
            continue
        if home_out!=mid:
            # Ongoing market convention is 1st outcome ID == market ID.
            # Fail closed rather than guess which team gets the handicap.
            continue
        result[mid]=(h,home_out,away_out)
    return result

def american(p):
    try:
        n=int(str(p).strip().replace('+',''))
        if n<=-100 or n>=100: return n
    except (ValueError,TypeError): pass
    return None

def active_price(obj):
    if not isinstance(obj,dict): return None
    p=(obj.get('players') or {}).get('0')
    if not isinstance(p,dict) or p.get('active') is not True: return None
    try: decimal=float(p.get('price'))
    except (ValueError,TypeError): return None
    if not math.isfinite(decimal) or decimal<=1.01: return None
    a=american(p.get('priceAmerican'))
    if a is None:
        a=round((decimal-1)*100) if decimal>=2 else round(-100/(decimal-1))
    if not (a<=-100 or a>=100): return None
    return {'decimal':decimal,'american':a,'changedAt':p.get('bookmakerChangedAt') or p.get('changedAt')}

def spreads_for_book(board, catalog):
    if not isinstance(board,dict): return []
    if board.get('suspended') is True or board.get('bookmakerIsActive') is False: return []
    candidates=[]
    for market_id,market in (board.get('markets') or {}).items():
        meta=catalog.get(str(market_id))
        if not meta or not isinstance(market,dict): continue
        h,home_out,away_out=meta
        outcomes=market.get('outcomes') or {}
        home=active_price(outcomes.get(home_out,{}))
        away=active_price(outcomes.get(away_out,{}))
        if not home or not away: continue
        imbalance=abs(1/home['decimal']-1/away['decimal'])
        # Conservative cap; a clearly one-sided extreme alternate ladder is not a main spread.
        if imbalance>0.22: continue
        candidates.append({'homeSpread':h,'homePrice':home['american'],
          'awayPrice':away['american'],'homeQuoteTime':home['changedAt'],
          'awayQuoteTime':away['changedAt'],'imbalance':imbalance})
    return candidates

def choose_quote(books, catalog):
    choices={}
    for book in BOOKS:
        ladders=spreads_for_book(books.get(book),catalog)
        if ladders: choices[book]=ladders
    if not choices: return None
    anchors=[min(rows,key=lambda r:(r['imbalance'],abs(r['homeSpread'])))['homeSpread'] for rows in choices.values()]
    consensus=Counter(anchors).most_common(1)[0][0]
    for name in BOOKS:
        if name not in choices: continue
        # If book has alt spreads, prefer the closest full-game line to the
        # independently inferred central line; never use the first market in JSON.
        best=min(choices[name],key=lambda r:(abs(r['homeSpread']-consensus),r['imbalance']))
        return dict(best,book=name,consensusLine=consensus,anchorBooks=len(choices))
    return None

def pick_team(name,abbr):
    if name in TEAMS: return TEAMS[name]
    a=TEAM_ABBR.get(str(abbr).upper(),str(abbr).upper())
    return a if a in TEAMS.values() else None

def predict(away,home,home_spread,hp,ap,model):
    teams=model['teams'];beta=model['beta']
    assert len(beta)==len(teams)+1
    residual=beta[0]+beta[teams.index(home)+1]-beta[teams.index(away)+1]
    mu=-home_spread+residual;market=-home_spread;sigma=13.5
    cdf=lambda x:0.5*(1+math.erf(x/math.sqrt(2)))
    if float(market).is_integer():
        ph=1-cdf((market+.5-mu)/sigma);pa=cdf((market-.5-mu)/sigma);push=max(0,1-ph-pa)
    else:
        ph=1-cdf((market-mu)/sigma);pa=1-ph;push=0.
    side='HOME' if residual>=0 else 'AWAY'
    win,lose=(ph,pa) if side=='HOME' else (pa,ph)
    price=hp if side=='HOME' else ap
    profit=(100/abs(price)) if price<0 else price/100
    ev=win*profit-lose
    return {'model':model['version'],'trainingGames':model['trainingGames'],
      'side':side,'pickTeam':home if side=='HOME' else away,
      'pickSpread':home_spread if side=='HOME' else -home_spread,
      'pickPrice':price,'projectedHomeMargin':round(mu,3),
      'marketHomeMargin':-home_spread,'residualHomePoints':round(residual,3),
      'coverProbabilityConditional':round(win/(win+lose),6),
      'pushProbability':round(push,6),'estimatedEVPerUnit':round(ev,6),
      'passesResearchThreshold':ev>=.02 and abs(residual)>=1.25,
      'certifiedEdge':False}

def main():
    model=json.loads(MODEL.read_text())
    now=utcnow()
    past={'frozen':[]}
    if OUT.exists():
        try: past=json.loads(OUT.read_text())
        except (ValueError,OSError): raise RuntimeError('Existing archive invalid; refusing overwrite')
    frozen={r['fixtureId']:r for r in past.get('frozen',[]) if r.get('fixtureId')}
    # /account is unmetered. Don't consume the remaining free-tier allowance
    # needed by moneyline/totals engines. If account shape is unfamiliar,
    # proceed but still keep the hard per-run MAX_FIXTURES cap.
    try:
        account=api_get('account')
        def quota_fields(obj):
            if isinstance(obj,dict):
                if 'request_limit' in obj and 'request_count' in obj:
                    return int(obj['request_limit']),int(obj['request_count'])
                for value in obj.values():
                    x=quota_fields(value)
                    if x: return x
            if isinstance(obj,list):
                for item in obj:
                    x=quota_fields(item)
                    if x: return x
            return None
        q=quota_fields(account)
        if q and q[0]-q[1]<=MIN_QUOTA_RESERVE:
            print('R3 capture skipped: reserving API quota for other NFL engines.')
            return
    except (ValueError,TypeError,RuntimeError) as exc:
        print('Could not check quota; aborting rather than risk other engines:',str(exc))
        return
    # One schedule request; one market catalogue; only games actually quoted.
    today=now.date()
    f=records(api_get('fixtures',tournamentId=NFL_TOURNAMENT,**{
        'from':today.isoformat(),'to':(today+dt.timedelta(days=3)).isoformat()}))
    # Do not fetch odds or make picks once kickoff is past, even if API status lags.
    f=[x for x in f if x.get('sportId') in (NFL_SPORT,str(NFL_SPORT)) and
       x.get('tournamentId') in (NFL_TOURNAMENT,str(NFL_TOURNAMENT)) and
       parse_dt(x.get('startTime')) and now<parse_dt(x['startTime'])<=now+dt.timedelta(hours=CAPTURE_HORIZON_HOURS) and
       x.get('statusId') in (0,'0',None)]
    f=sorted(f,key=lambda x:x['startTime'])[:MAX_FIXTURES]
    if not f:
        print('No upcoming NFL fixtures; preserved previously frozen picks.');return
    if all(str(x.get('fixtureId','')) in frozen for x in f):
        print('All eligible pregame fixtures already frozen; no odds requests needed.')
        return
    catalog=market_catalog(api_get('markets',sportId=NFL_SPORT))
    if not catalog: raise RuntimeError('No resolvable NFL handicap catalogue; refusing to publish guesses')
    statuses=[]
    for item in f:
        fid=str(item.get('fixtureId',''))
        home=pick_team(item.get('participant1Name'),item.get('participant1Abbr'))
        away=pick_team(item.get('participant2Name'),item.get('participant2Abbr'))
        kickoff=parse_dt(item['startTime'])
        if not fid or not home or not away or home==away:
            statuses.append({'fixtureId':fid,'status':'UNKNOWN_TEAM_OR_FIXTURE'});continue
        if fid in frozen:
            statuses.append({'fixtureId':fid,'away':away,'home':home,'kickoffUtc':z(kickoff),'status':'ALREADY_FROZEN'})
            continue
        # Official odds, not a reconstructed or assumed line; API key stays server-side.
        odds=api_get('odds',fixtureId=fid,bookmakers=','.join(BOOKS),language='en')
        q=choose_quote((odds or {}).get('bookmakerOdds') or {},catalog)
        if not q:
            statuses.append({'fixtureId':fid,'away':away,'home':home,'kickoffUtc':z(kickoff),'status':'NO_TWO_SIDED_SPREAD'});continue
        capture=utcnow()
        if capture>=kickoff:
            statuses.append({'fixtureId':fid,'status':'KICKOFF_PASSED_DURING_REQUEST'});continue
        # We do NOT block calculations on odds age, but we explicitly expose it.
        quote_dates=[parse_dt(q['homeQuoteTime']),parse_dt(q['awayQuoteTime'])]
        if any(t and t>kickoff for t in quote_dates):
            statuses.append({'fixtureId':fid,'status':'INVALID_POST_KICKOFF_QUOTE'});continue
        result=predict(away,home,q['homeSpread'],q['homePrice'],q['awayPrice'],model)
        entry={'fixtureId':fid,'away':away,'home':home,'kickoffUtc':z(kickoff),
          'frozenAtUtc':z(capture),'quoteObservedAtUtc':z(capture),
          'bookmaker':q['book'],'homeSpread':q['homeSpread'],
          'homeSpreadPrice':q['homePrice'],'awaySpreadPrice':q['awayPrice'],
          'bookmakerQuoteTimeHome':q['homeQuoteTime'],'bookmakerQuoteTimeAway':q['awayQuoteTime'],
          'source':'OddsPapi v4 / odds','quoteVerification':'API_RECEIVED_PREKICKOFF',
          'provenance':'R3 reconstructed; prospective GitHub Actions capture',
          'modelOutput':result}
        frozen[fid]=entry
        statuses.append({'fixtureId':fid,'away':away,'home':home,'kickoffUtc':z(kickoff),'status':'FROZEN'})
        print(f'Frozen {away} @ {home} [{fid}] from {q["book"]} with verified two-sided spread')
        time.sleep(0.7)
    final={'schema':'sel.r3.pregame.v1','generatedAtUtc':z(utcnow()),
     'model':model['version'],'status':'RESEARCH_ONLY_NOT_CERTIFIED',
     'frozen':sorted(frozen.values(),key=lambda r:r['kickoffUtc']),
     'upcomingStatus':statuses,
     'notes':'Frozen picks never overwritten; no postkickoff inference; sample is not a validated profitable model.'}
    OUT.parent.mkdir(parents=True,exist_ok=True)
    OUT.write_text(json.dumps(final,indent=2,sort_keys=True)+'\n')
    print(f'Success: {len(final["frozen"])} frozen R3 predictions retained; {len(statuses)} fixtures checked')

if __name__=='__main__':
    try: main()
    except Exception as exc:
        print('R3 sync FAILED:',str(exc),file=sys.stderr);sys.exit(1)
